export * from './utilisateur-profil.entity';
export * from './utilisateur-profil.dto';
export * from './utilisateur-profil.module';
export * from './utilisateur-profil.service'; 
export * from './utilisateur-profil.controller'; 