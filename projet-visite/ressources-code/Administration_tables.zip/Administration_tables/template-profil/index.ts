export * from './template-profil.entity';
export * from './template-profil.dto';
export * from './template-profil.module';
export * from './template-profil.service'; 
export * from './template-profil.controller'; 